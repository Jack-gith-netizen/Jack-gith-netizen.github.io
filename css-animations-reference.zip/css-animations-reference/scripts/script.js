// this is to enable / disable the sections

const btn1 = document.getElementById('button-basics') ;
const btn2 = document.getElementById('button-rep-dir') ;
const btn3 = document.getElementById('button-timing') ;
const btn4 = document.getElementById('button-animation') ;

const section1 = document.querySelector('.section-basics');
const section2 = document.querySelector('.section-repetition-direction');
const section3 = document.querySelector('.section-timing');
const section4 = document.querySelector('.section-animation');

section1.style.display = 'block';
section2.style.display = 'block';
section3.style.display = 'block';
section4.style.display = 'block';

const grid = document.querySelector('.grid');

function toggleSection(section) {
    console.log(section.style.display)
    if (section.style.display == 'block') {
        section.style.display = 'none';
    }
    else {
        section.style.display = 'block';
    }
}

btn1.addEventListener('click', function() {
    toggleSection(section1);
})
btn2.addEventListener('click', function() {
    toggleSection(section2);
})
btn3.addEventListener('click', function() {
    toggleSection(section3);
})
btn4.addEventListener('click', function() {
    toggleSection(section4);
})